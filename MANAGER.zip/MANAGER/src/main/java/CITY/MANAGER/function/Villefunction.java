package CITY.MANAGER.function;

import CITY.MANAGER.entity.Ville;

public class Villefunction {
    int i;
    int j;
}
