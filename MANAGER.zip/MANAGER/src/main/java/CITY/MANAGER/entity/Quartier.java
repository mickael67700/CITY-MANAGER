package CITY.MANAGER.entity;
import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="QUARTIER")
public class Quartier extends Ville implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Id", nullable = false)
    private int id;

    @Column(name = "TYPE_QUARTIER", length = 64, nullable = true)
    private String typeQuartier;


    @Column(name = "VALEUR", length = 10, nullable = true)
    private int valeur;

    @Column(name = "X", length = 10, nullable = true)
    private int abscisse;

    @Column(name = "Y", length = 10, nullable = true)
    private int ordonnee;

    @Column(name = "INFLUENCE_MAX", length = 10, nullable = true)
    private int influence;

    @Column(name = "ZONE_INFLUENCE", length = 5, nullable = true)
    private int zoneInfluence;
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.REMOVE})

    private Ville ville;

    public Quartier(String rte, int i, int x, int y, int i1, int i2, String martignas) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public  String getTypeQuartier() {
        return typeQuartier;
    }

    public void setTypeQuartier(String typeQuartier) {
        this.typeQuartier = typeQuartier;
    }

    public  int getValeur() {
        return valeur;
    }

    public void setValeur(int valeur) {
        this.valeur = valeur;
    }

    public  int getAbscisse() {
        return abscisse;
    }

    public  void setAbscisse(int abscisse) {
        this.abscisse = abscisse;
    }

    public int getOrdonnee() {
        return ordonnee;
    }

    public  void setOrdonnee(int ordonnee) {
        this.ordonnee = ordonnee;
    }

    public  int getInfluence() {
        return influence;
    }

    public void setInfluence(int influence) {
        this.influence = influence;
    }

    public  float getZoneInfluence() {
        return zoneInfluence;
    }

    public void setZoneInfluence(int zoneInfluence) {
        this.zoneInfluence = zoneInfluence;
    }

    public Ville getVille() {
        return ville;
    }

    public void setVille(Ville ville) {
        this.ville = ville;
    }
    public Quartier(){}
    public Quartier(String typeQuartier, int valeur, int abscisse, int ordonnee, int influence, int zoneInfluence) {
        this.typeQuartier = typeQuartier;
        this.valeur = valeur;
        this.abscisse = abscisse;
        this.ordonnee = ordonnee;
        this.influence = influence;
        this.zoneInfluence = zoneInfluence;
    }
    public Quartier(String typeQuartier, int abscisse, int ordonnee, int influence) {
        this.typeQuartier = typeQuartier;
        this.valeur = 0;
        this.abscisse = abscisse;
        this.ordonnee = ordonnee;
        this.influence = influence;
        this.zoneInfluence = 0;

    }

}
