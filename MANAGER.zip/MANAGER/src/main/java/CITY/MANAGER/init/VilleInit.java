package CITY.MANAGER.init;
import org.springframework.stereotype.Component;
import CITY.MANAGER.repository.VilleRepository;


@Component
public class VilleInit {
    private VilleRepository villeRepository;

}