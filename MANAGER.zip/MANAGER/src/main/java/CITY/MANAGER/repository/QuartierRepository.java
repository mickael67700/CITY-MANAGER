package CITY.MANAGER.repository;

import CITY.MANAGER.entity.Quartier;
import CITY.MANAGER.entity.Ville;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

public interface QuartierRepository extends CrudRepository<Quartier, Integer> {
    public List<Quartier>findAll();

    public Quartier findQuartierById(int id);
    public Quartier save(Quartier quartier);
   /* public List<Quartier>findAllByNomVille(String nomVille); */


    public Quartier findQuartierById(String typeQuartier);
    public List<Quartier>findByNomVille(String nomVille);

}
